﻿using UnityEngine;

namespace DefaultNamespace
{
    public class Enemy : MonoBehaviour
    {
        
    }
}